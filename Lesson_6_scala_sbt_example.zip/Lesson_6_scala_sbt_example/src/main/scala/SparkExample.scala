import org.apache.spark.rdd.RDD
import org.apache.spark.sql._
import org.apache.spark.sql.functions._
import org.apache.spark.storage.StorageLevel

object SparkExample {
  def main(args: Array[String]): Unit = {
    // Создает сессию спарка
    val spark = SparkSession.builder()
      // адрес мастера
      .master("local[*]")
      // имя приложения в интерфейсе спарка
      .appName("made-demo")
      // взять текущий или создать новый
      .getOrCreate()

    // синтаксический сахар для удобной работы со спарк
    import spark.implicits._

    // прочитаем датасет https://www.kaggle.com/andrewmvd/trip-advisor-hotel-reviews

    val df = spark.read
      .option("header", "true")
      .option("inferSchema", "true")
      .csv("trip_x10.csv")

    val flatten = df
      .select(split(col("Review"), " "))
      .as[Array[String]]
      .flatMap(x => x)


//     df.cache() // позволяет сохранить промежуточные результаты в оперативной памяти
//     df.persist(StorageLevel.MEMORY_AND_DISK) // аналогично, но нужно указывать StorageLevel, можно созранять на диск

    val counts = flatten
      .groupBy(col("value"))
      .count()
      .orderBy(desc("count"))

    counts.show
  }
}

